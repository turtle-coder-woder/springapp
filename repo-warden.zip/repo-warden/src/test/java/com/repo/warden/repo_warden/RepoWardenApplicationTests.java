package com.repo.warden.repo_warden;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RepoWardenApplicationTests {

	@Test
	void contextLoads() {
	}

}
