package com.repo.warden.repo_warden;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RepoWardenApplication {

	public static void main(String[] args) {
		SpringApplication.run(RepoWardenApplication.class, args);
	}

}
